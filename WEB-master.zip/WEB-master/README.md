# WEB
Wesite theme for trainning purposes on Odin Project. For publishing just move from WEB folder to the master.
